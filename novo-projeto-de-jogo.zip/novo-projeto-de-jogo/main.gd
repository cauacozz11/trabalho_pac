extends Node2D

@onready var arrow = $Arrow
@onready var target = $Target
@onready var velocity_input = $VelocityInput
@onready var angle_input = $AngleInput
@onready var distance_label = $DistanceLabel
@onready var height_label = $HeightLabel

var target_distance
var target_height

func _ready():
	randomize_target()

func randomize_target():
	target_distance = randi() % 400 + 300
	target_height = randi() % 200 + 100
	
	target.position.x = target_distance
	target.position.y = 600 - target_height
	
	distance_label.text = "Distância: " + str(target_distance)
	height_label.text = "Altura: " + str(target_height)

func _on_shoot_button_pressed():
	var speed = float(velocity_input.text)
	var angle = float(angle_input.text)
	
	arrow.position = Vector2(100, 600)
	arrow.launch(speed, angle)
